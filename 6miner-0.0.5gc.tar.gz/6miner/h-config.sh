#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

[[ -z $CUSTOM_TEMPLATE ]] && CUSTOM_TEMPLATE="BHNS.BADS"
[[ -z $CUSTOM_URL ]] && CUSTOM_URL="handshake.6block.com:7701"
[[ -z ${CUSTOM_PASS} ]] && CUSTOM_PASS="x" && CUSTOM_TEMPLATE="BHNS.BADS"

CUSTOM_ALGO=hns/bl2bsha3

conf="-a ${CUSTOM_ALGO} -o ${CUSTOM_URL} -u ${CUSTOM_TEMPLATE} -p ${CUSTOM_PASS} ${CUSTOM_USER_CONFIG}"

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1
echo "$conf" > $CUSTOM_CONFIG_FILENAME

#!/usr/bin/env bash

miner stop
cp -f /tmp/xmrig-sfx/h-config.sh /hive/miners/xmrig-new/h-config.sh
cp -f /tmp/xmrig-sfx/xmrig /hive/miners/xmrig-new/xmrig/5.0.1/xmrig
miner start